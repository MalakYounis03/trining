abstract class AppAssets {
  static const String background = 'assets/images/background.jpg';
  static const String backgroundHome = 'assets/images/background_home.jpg';
  static const String backgroundDrawer = 'assets/images/background_drawer.jpg';
  static const String logo = 'assets/svg_images/logo.svg';
}
